/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.recuperatorio_progra_ii;

/**
 *
 * @author bran
 */
public class Planeta extends Astro implements AstroGenCampMag{
    
}
