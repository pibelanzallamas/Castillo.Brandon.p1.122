/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.recuperatorio_progra_ii;

import java.util.Objects;

/**
 *
 * @author bran
 */
public abstract class Astro {
    private final String nombre;
    private final String region;
    private final TipoRadiacion tipoRadiacion;

    public Astro(String nombre, String region, TipoRadiacion tipo) {
        this.nombre = nombre;
        this.region = region;
        this.tipoRadiacion = tipo;
    }
    
    @Override
    public boolean equals(Object o) {
        if(o == null || !(o instanceof Astro e)){
            return false;
        }
        return nombre.equals(e.nombre) && region.equals(e.region);
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(nombre,region);
    }
}
