/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.recuperatorio_progra_ii;

import java.util.ArrayList;

/**
 *
 * @author bran
 */
public class Estudio {
    private ArrayList<Astro> listaAstros = new ArrayList<>();
    
    public void agregarAstro (Astro a){
        try{
            isNull(a);
            validarAstro(a);
            listaAstros.add(a);
        }catch(AstroExistenteException ex){
            System.out.println(ex.getMessage());
        }catch(NullPointerException exn){
            System.out.println(exn.getMessage());
        }
    }
    
    public void isNull(Object o){
        if (o == null) throw new IllegalArgumentException("El astro no puede ser null.\n");
    }
    
    public void validarAstro(Astro a){
        if (listaAstros.contains(a)){
            throw new AstroExistenteException("El astro ya esta registrado.");
        }
    }
    
    public void mostrarAstros(){
        for (Astro a : listaAstros){
            System.out.println(a.toString());
        }
    }
    
    
    public void generarCamposMagneticos(){
        for (Astro a : listaAstros){
            if(a instanceof AstroGenCampMag ac){
                ac.generarCampoMagnetico();
            }else{
                System.out.println("La especie " + a.getNombre() + "no puede moverse.");
            }
        } 
        System.out.println("");
    }
    
    public void modificarOrbitas(){
        for (Especie e : listaEspecies){
            if(e instanceof EspecieQueComeYSeMueve em){
                em.moverse();
            }else{
                System.out.println("La especie " + e.getNombre() + "no puede moverse.");
            }
        } 
        System.out.println("");
    }
}
