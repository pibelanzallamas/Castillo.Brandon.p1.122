/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.recuperatorio_progra_ii;

/**
 *
 * @author bran
 */
public class Cometa extends Astro implements AstroModOrbita{
    
    private int periodoOrbital;

    public Cometa(String nombre, String region, TipoRadiacion tipo, int periodoOrbita) {
        super(nombre, region, tipo);
        this.periodoOrbital = periodoOrbital;
    }
    
    
    
    @Override
    public void modificarOrbita() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
