/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parcialacuario;

/**
 *
 * @author bran
 */
public class Molusco extends Especie implements EspecieQueComeYSeMueve{
    
    private final String tipoConcha;

    public Molusco(TipoDeAgua tipoDeAgua, String nombre, String tanque, String tipoConcha) {
        super(tipoDeAgua, nombre, tanque);
        this.tipoConcha = tipoConcha;
    }

    public String getTipoConcha(){return tipoConcha;}

    @Override
    public void alimentar() {
        System.out.println("Se alimenta el: " + this.getNombre());
    }
    
    @Override
    public void moverse() {
        System.out.println("Se mueve el: " + this.getNombre());
    }
    
    @Override
    public String toString(){
        String base = super.toString();
        StringBuilder sb = new StringBuilder();
        sb.append(base);
        sb.append("Tipo de concha: ").append(this.getTipoConcha());
        sb.append(System.lineSeparator());
        return sb.toString();
    }
}
