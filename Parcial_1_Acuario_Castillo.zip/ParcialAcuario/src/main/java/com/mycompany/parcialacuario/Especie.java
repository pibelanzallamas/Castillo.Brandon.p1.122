/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parcialacuario;

import java.util.Objects;

/**
 *
 * @author bran
 */
public abstract class Especie {
    
    private final TipoDeAgua tipoDeAgua;
    private final String nombre;
    private final String tanque;

    public Especie(TipoDeAgua tipoDeAgua, String nombre, String tanque) {
        this.tipoDeAgua = tipoDeAgua;
        this.nombre = nombre;
        this.tanque = tanque;
    }
    
    public String getNombre(){return nombre; }
    
    public String getTanque(){return tanque;}
   
    public String getTipoDeAgua(){return tipoDeAgua.toString();}
    
    protected void reproducirse(){
        System.out.println(this.nombre + " reproduciendose...");
    }
    
    protected void respirar(){
        System.out.println(this.nombre + " respirando...");
    }
 
    @Override
    public boolean equals(Object o) {
        if(o == null || !(o instanceof Especie e)){
            return false;
        }
        return nombre.equals(e.nombre) && tanque.equals(e.tanque);
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(nombre,tanque);
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Nombre: ").append(this.nombre);
        sb.append(System.lineSeparator());
        sb.append("Tanque: ").append(this.getTanque());
        sb.append(System.lineSeparator());
        sb.append("Tipo Agua: ").append(this.getTipoDeAgua());
        sb.append(System.lineSeparator());
        return sb.toString();
    }
}
