/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parcialacuario;

/**
 *
 * @author bran
 */
public class Coral extends Especie{
    
    private final int profunIdealM;

    public Coral(TipoDeAgua tipoDeAgua, String nombre, String tanque, int profunIdealM) {
        super(tipoDeAgua, nombre, tanque);
        this.profunIdealM = profunIdealM;
    }

    public int getProfunIdeal(){return profunIdealM;}
    
    @Override
    public String toString(){
        String base = super.toString();
        StringBuilder sb = new StringBuilder();
        sb.append(base);
        sb.append("Profundidad Ideal en metros: ").append(this.getProfunIdeal());
        sb.append(System.lineSeparator());
        return sb.toString();
    }
}
