/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.mycompany.parcialacuario;

/**
 *
 * @author bran
 */
public class EspecieExistenteExcepcion extends RuntimeException {
    
    private final static String MENSAJE = "Especie Existente.";
    
    public EspecieExistenteExcepcion(){
        this(MENSAJE);
    }
    
    public EspecieExistenteExcepcion(String mensaje){
        super(mensaje);
    }
    
}
