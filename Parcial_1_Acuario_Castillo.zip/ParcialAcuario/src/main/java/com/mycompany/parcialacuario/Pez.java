/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parcialacuario;

/**
 *
 * @author bran
 */
public class Pez extends Especie implements EspecieQueComeYSeMueve{
    
    private final int longMaxCm;

    public Pez(TipoDeAgua tipoDeAgua, String nombre, String tanque, int longMaxCm) {
        super(tipoDeAgua, nombre, tanque);
        this.longMaxCm = longMaxCm;
    }

    public int getLongMaxCm(){return longMaxCm;}
    
    @Override
    public void alimentar() {
        System.out.println(this.getNombre() + " se alimenta...");
    }
    
    @Override
    public void moverse() {
        System.out.println("Se mueve el: " + this.getNombre());
    }
    
    @Override
    public String toString(){
        String base = super.toString();
        StringBuilder sb = new StringBuilder();
        sb.append(base);
        sb.append("Long máx en cm: ").append(this.getLongMaxCm());
        sb.append(System.lineSeparator());
        return sb.toString();
    }
}
