/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.parcialacuario;

import java.util.ArrayList;

/**
 *
 * @author bran
 */
public class ParcialAcuario {

    public static void main(String[] args) {
        
        Aquario mundomarino = new Aquario();
        
        Pez p1 = new Pez(TipoDeAgua.AGUA_SALADA, "Pez Espada", "T1", 120); 
        Pez p2 = new Pez(TipoDeAgua.AGUA_SALADA, "Pez Espada", "T1", 120); 
        Coral c1 = new Coral(TipoDeAgua.AGUA_SALADA, "Coral Rosa", "T2", 50);
        Molusco m1 = new Molusco(TipoDeAgua.AGUA_SALADA, "Molusco", "T3", "Bivalva");
        
        System.out.println("----Agregando Especies-----\n");
        
        mundomarino.agregarEspecie(p1);
        mundomarino.agregarEspecie(p2); //especie repetida
        mundomarino.agregarEspecie(c1);
        mundomarino.agregarEspecie(m1);
        
        System.out.println("----Mostrar Especies-----\n");
        
        mundomarino.mostrarEspecies();
        
        System.out.println("----Moviendo Especies-----\n");
        
        mundomarino.moverEspecies();
        
        System.out.println("----Funciones Biologicas-----\n");
        
        mundomarino.realizarFuncionesBiologicas();
        
        System.out.println("----Filtrando Especies-----\n");
        
        mundomarino.filtrarPorTipoDeAgua(TipoDeAgua.AGUA_SALADA);
        
    }
    
}
