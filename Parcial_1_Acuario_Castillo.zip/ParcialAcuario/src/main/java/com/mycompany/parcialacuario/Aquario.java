/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parcialacuario;

import java.util.ArrayList;

/**
 *
 * @author bran
 */
public class Aquario {
    
    private ArrayList<Especie> listaEspecies = new ArrayList<>();

    public void agregarEspecie(Especie e){
        try{
            validarEspecie(e);
            listaEspecies.add(e);
        }catch(RuntimeException exc){
            System.out.println(exc.getMessage());
        }
    }
    
    public void validarEspecie(Especie e){
        isNull(e);
        if(listaEspecies.contains(e)){
            throw new EspecieExistenteExcepcion("La especie ya está registrada.\n");
        }
    }
    
    private void isNull(Especie e){
        if(e == null) throw new IllegalArgumentException("La especie no puede ser null.");
    }
    
    public void mostrarEspecies(){
        for (Especie e : listaEspecies){
            System.out.println(e.toString());
        }
    }
    
    public void moverEspecies(){
        for (Especie e : listaEspecies){
            if(e instanceof EspecieQueComeYSeMueve em){
                em.moverse();
            }else{
                System.out.println("La especie " + e.getNombre() + "no puede moverse");
            }
        } 
        System.out.println("");
    }
    
    public void realizarFuncionesBiologicas(){
        for (Especie e : listaEspecies){
            e.respirar();
            e.reproducirse();
        }
        System.out.println("");
    }
    
    public ArrayList<Especie> filtrarPorTipoDeAgua(TipoDeAgua tipo){
        ArrayList<Especie> listaFiltrada = new ArrayList<>();
        
        for(Especie e : listaEspecies){
            if(e.getTipoDeAgua() == tipo.toString()){
                listaFiltrada.add(e);
                System.out.println(e);
            }
        }
        
        return listaFiltrada;
    }
}
